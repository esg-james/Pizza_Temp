

#import <Foundation/Foundation.h>
#import "Kitchen.h"


@interface KitchenManager : NSObject <KitchenDelegate>



@end

